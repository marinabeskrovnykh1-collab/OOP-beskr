﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportWinFormsApp1.Data;

public class WorkoutInfo
{
    [Key]
    public int IdInfo { get; set; }

    public double? VerticalSpeed { get; set; }

    public double? Altitude { get; set; }

    public DateTime? TimeISO8601 { get; set; }
    public int WorkoutId { get; set; }

    [ForeignKey("WorkoutId")]
    public Workout Workout { get; set; }
}
