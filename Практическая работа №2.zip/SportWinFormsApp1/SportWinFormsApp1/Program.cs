using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using sportWinFormsApp1;
using sportWinFormsApp1.Data; 
using sportWinFormsApp1;
using sportWinFormsApp1.Services;

namespace sportWinFormsApp1 
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            var services = new ServiceCollection();

            services.AddDbContext<WorkoutContext>(options =>
                options.UseSqlite("Data Source=workouts.db"));

            services.AddTransient<WorkoutService>();
            services.AddTransient<Form1>();

            using var serviceProvider = services.BuildServiceProvider();

            var form = serviceProvider.GetRequiredService<Form1>();

            Application.Run(form);
        }
    }
}