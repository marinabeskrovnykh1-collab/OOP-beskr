﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportWinFormsApp1.Models.Activity;

internal class Header
{
    public DateTime DateTime { get; set; } 

    public int Distance { get; set; } 
    
}
