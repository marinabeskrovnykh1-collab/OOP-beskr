﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace sportWinFormsApp1.Models.Activity
{
    internal class Samples
    {
        public double? VerticalSpeed { get; set; }

        public double? Altitude { get; set; }

        public DateTime? TimeISO8601 { get; set;}
    }
}
