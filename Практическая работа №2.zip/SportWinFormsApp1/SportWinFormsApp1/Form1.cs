﻿using sportWinFormsApp1.Models.Activity;
using System.Text.Json;
using System.Windows.Forms;
using sportWinFormsApp1.Data;
using sportWinFormsApp1.Services;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sportWinFormsApp1
{
    public partial class Form1 : Form
    {

        private readonly WorkoutService _workoutService;
        public Form1(WorkoutService workoutService)
        {
            InitializeComponent();

            _workoutService = workoutService;

            LoadWorkouts();
        }

        private void LoadWorkouts()
        {
            try
            {

                var data = _workoutService.GetAll();

                dataGridView3.DataSource = data ?? new List<Workout>();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке тренировок из БД: {ex.Message}");
            }
        }

        private void открытьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var fileName = openFileDialog1.FileName;

                try
                {
                    var content = File.ReadAllText(fileName);

                    var data = JsonSerializer.Deserialize<ActivityModel>(content);

                    if (data == null || data.DeviceLog == null)
                    {
                        MessageBox.Show("Пусто");
                    }

                    var header = data.DeviceLog.Header;

                    //listBox1.Items.Clear();

                    //listBox1.Items.Add($"Имя файла: {Path.GetFileName(fileName)}");

                    //listBox1.Items.Add($"Дата тренировки: {header.DateTime.ToString("dd.MM.yy HH:mm:ss")}");
                    //listBox1.Items.Add($"Дистанция: {header.Distance}");

                    //dataGridView1.Rows.Clear();
                    //dataGridView1.Columns.Clear();


                    //dataGridView1.Columns.Add("TimeISO8601", "TimeISO8601");
                    //dataGridView1.Columns.Add("VerticalSpeed", "VerticalSpeed");
                    //dataGridView1.Columns.Add("Altitude", "Altitude");

                    var samples = data.DeviceLog.Samples;

                    var validSamples = samples.Where(v => v.TimeISO8601.HasValue && v.VerticalSpeed.HasValue && v.Altitude.HasValue);

                    //foreach (var k in validSamples)
                    //{
                    //    dataGridView1.Rows.Add(
                    //        k.TimeISO8601?.ToString("yyyy-MM-dd HH:mm:ss.fff") ?? "",
                    //        k.VerticalSpeed?.ToString() ?? "",
                    //        k.Altitude?.ToString() ?? ""
                    //    );
                    //}

                    //dataGridView2.Rows.Clear();
                    //dataGridView2.Columns.Clear();

                    //dataGridView2.Columns.Add("Index", "Номер пары");
                    //dataGridView2.Columns.Add("TimeFrom", "Время в начале");
                    //dataGridView2.Columns.Add("TimeTo", "Время в конце");
                    //dataGridView2.Columns.Add("SpeedFrom", "Скорость в начале");
                    //dataGridView2.Columns.Add("SpeedTo", "Скорость в конце");
                    //dataGridView2.Columns.Add("SpeedDelta", "Изменение скорости ");
                    //dataGridView2.Columns.Add("AltitudeDelta", "Изменение высоты ");
                    //dataGridView2.Columns.Add("AltitudeFrom", "Высота в начале");
                    //dataGridView2.Columns.Add("AltitudeTo", "Высота в конце");
                    //dataGridView2.Columns.Add("TimeDeltaSec", "Временной интервал между началом и концом");

                    //var speedSamples = data.DeviceLog.Samples.Where(n => n.VerticalSpeed.HasValue &&
                    //    n.VerticalSpeed.Value != 0 &&
                    //    n.Altitude.HasValue &&
                    //    n.Altitude.Value != 0 &&
                    //    n.TimeISO8601.HasValue).ToList();

                    //for (int i = 0; i < speedSamples.Count - 1; i++)
                    //{
                    //    var s1 = speedSamples[i];
                    //    var s2 = speedSamples[i + 1];

                    //    var speed1 = s1.VerticalSpeed.Value;
                    //    var speed2 = s2.VerticalSpeed.Value;
                    //    var altitude1 = s1.Altitude.Value;
                    //    var altitude2 = s2.Altitude.Value;

                    //    var speedDelta = speed2 - speed1;

                    //    var altitudeDelta = altitude2 - altitude1;

                    //    var timeDeltaSec = (s2.TimeISO8601.Value - s1.TimeISO8601.Value).TotalSeconds;

                    //    dataGridView2.Rows.Add(
                    //        i,
                    //        s1.TimeISO8601?.ToString("yyyy-MM-dd HH:mm:ss.fff") ?? "",
                    //        s2.TimeISO8601?.ToString("yyyy-MM-dd HH:mm:ss.fff") ?? "",
                    //        speed1.ToString("F2"),
                    //        speed2.ToString("F2"),
                    //        speedDelta.ToString("F2"),
                    //        altitudeDelta.ToString("F1"),
                    //        altitude1.ToString("F1"),
                    //        altitude2.ToString("F1"),
                    //        timeDeltaSec.ToString("F2")
                    //    );
                    //}

                    var fileNameForDb = Path.GetFileName(fileName);
                    
                    bool isExists = _workoutService.IsWorkoutExists(fileNameForDb, header.Distance, header.DateTime);

                    if (isExists)
                    {
                        MessageBox.Show("Эта тренировка уже была загружена ранее!", "Дубликат", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {

                        var newWorkout = new Workout

                        {
                            FileName = fileNameForDb,
                            Distance = header.Distance,
                            Time = header.DateTime,
                            Infos = new List<WorkoutInfo>() 
                        };

                        
                        foreach (var k in validSamples)
                        {
                            newWorkout.Infos.Add(new WorkoutInfo
                            {
                                TimeISO8601 = k.TimeISO8601,
                                VerticalSpeed = k.VerticalSpeed,
                                Altitude = k.Altitude
                            });
                        }

                        _workoutService.Add(newWorkout);

                        LoadWorkouts();
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Некорректный ({ex.Message})");
                }




            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var workoutId = (int)dataGridView3.Rows[e.RowIndex].Cells[0].Value;

            var workout = _workoutService.GetById(workoutId);

            listBox1.Items.Clear();

            if (workout != null)
            {

                listBox1.Items.Add($"Имя файла: {workout.FileName}");
                listBox1.Items.Add($"Дата тренировки: {workout.Time.ToString("dd.MM.yy HH:mm:ss")}");
                listBox1.Items.Add($"Дистанция: {workout.Distance}");
            }
        }
    }
}
